//Headerchar* GetTEST_STRING ITEM1(){return GetString(TEST_STRING ITEM1, "foo");}
char* GetTEST_STRING ITEM2(){return GetString(TEST_STRING ITEM2, "BAR");}
char* GetTEST_STRING SUB1ITEM2(){return GetString(TEST_STRING SUB1ITEM2, "BAR");}
IntegerItem Test Integer sub1item2BooleanItem Test BooleanEnumItem Test Enum