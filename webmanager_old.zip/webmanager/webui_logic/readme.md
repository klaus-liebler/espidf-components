# Hinweise
* Aus welchen Gründen auch immer müssen viele Libs als save-dev installiert werden. Eine globale Installation genügt nicht